import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commentaries',
  templateUrl: './commentaries.page.html',
  styleUrls: ['./commentaries.page.scss'],
})
export class CommentariesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
