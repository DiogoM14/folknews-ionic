import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HeaderCategoriesPage } from './header-categories.page';

const routes: Routes = [
  {
    path: '',
    component: HeaderCategoriesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HeaderCategoriesPageRoutingModule {}
