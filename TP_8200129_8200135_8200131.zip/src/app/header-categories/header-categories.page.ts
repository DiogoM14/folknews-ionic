import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-categories',
  templateUrl: './header-categories.page.html',
  styleUrls: ['./header-categories.page.scss'],
})
export class HeaderCategoriesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
