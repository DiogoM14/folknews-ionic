import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-new-details',
  templateUrl: './header-new-details.page.html',
  styleUrls: ['./header-new-details.page.scss'],
})
export class HeaderNewDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
